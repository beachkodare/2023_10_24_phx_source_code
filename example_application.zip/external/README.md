# 2023 10 23 CNE Demo UI Svc

### Cool lightweight service for demonstration

